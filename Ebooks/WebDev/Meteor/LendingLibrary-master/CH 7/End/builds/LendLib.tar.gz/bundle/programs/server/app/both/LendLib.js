(function(){lists = new Meteor.Collection('lists');


})();
